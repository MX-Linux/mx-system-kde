# mx-system-kde
kde plasma specific mx-system packaage
